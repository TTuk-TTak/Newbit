-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: i6a101.p.ssafy.io    Database: s06p12a101
-- ------------------------------------------------------
-- Server version	8.0.28-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `techblog`
--

DROP TABLE IF EXISTS `techblog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `techblog` (
  `techblog_code` int NOT NULL,
  `techblog_name` varchar(100) NOT NULL,
  `techblog_img` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `techblog`
--

LOCK TABLES `techblog` WRITE;
/*!40000 ALTER TABLE `techblog` DISABLE KEYS */;
INSERT INTO `techblog` VALUES (1,'LINE','https://i.ibb.co/BTCG2rJ/1.png'),(2,'카카오엔터테인먼트 FE 기술블로그','https://i.ibb.co/rx255xP/2.png'),(3,'화해 블로그','https://i.ibb.co/FKWHcbN/3.png'),(4,'SK C&C Tech Blog','https://i.ibb.co/qdR2TYH/4.png'),(5,'우아한형제들 기술 블로그','https://i.ibb.co/k2kqDNg/4.png'),(6,'TOAST UI','https://i.ibb.co/2nC9MFp/6.png'),(7,'카카오 기술 블로그','https://i.ibb.co/rx255xP/6.png'),(8,'지금 써보러 갑니다','https://i.ibb.co/k1cx8y4/7.png'),(9,'구글 Developer Korea Blog','https://i.ibb.co/DbfStH2/8.png'),(10,'요기요 기술 블로그','https://i.ibb.co/XsR4n5F/9.png'),(11,'Code Playground','https://i.ibb.co/D5ycx9Z/11.png'),(12,'teo','https://i.ibb.co/PgSfRJM/12.png'),(13,'리디북스','https://i.ibb.co/Y8htsJj/13.png'),(14,'강준현','https://i.ibb.co/1JPy5BZ/14.png'),(15,'사람인HR 기술 블로그','https://i.ibb.co/8zKsYK4/15.png'),(16,'NAVER D2','https://i.ibb.co/VLTYt1q/16.png'),(17,'오늘의집','https://i.ibb.co/xh75SHB/17.png'),(18,'Tecoble','https://i.ibb.co/LNPqqJk/18.png'),(19,'강남언니','https://i.ibb.co/9N5FHY6/19.png'),(20,'Brandi','https://i.ibb.co/0tZgTLV/20.png'),(21,'Hyperconnect Tech Blog','https://i.ibb.co/yq6CdW7/21.png'),(99,'스파르타 코딩클럽','https://i.ibb.co/r7FdTfz/99.png'),(23,'SOCAR','https://i.ibb.co/48NtD2V/23.png'),(24,'마이리얼트립','https://i.ibb.co/wSzMM7W/24.png'),(25,'네이버 플레이스','https://i.ibb.co/8PZHCL9/25.png'),(26,'직방','https://i.ibb.co/F8JNVF7/26.png'),(27,'유니크굿컴퍼니','https://i.ibb.co/8KwtZFk/27.png'),(28,'Watcha 팀 블로그','https://i.ibb.co/HGj0M7R/28.png'),(29,'29CM 기술블로그','https://i.ibb.co/19bqH98/29.png'),(30,'매쉬코리아 웹 프론트엔드 팀 블로그','https://i.ibb.co/ggPFTkv/30.png'),(31,'재그지그','https://i.ibb.co/Qj799jT/31.png'),(32,'딜리셔스','https://i.ibb.co/fNfFMcg/32.png'),(33,'Yun Blog','https://i.ibb.co/1JPy5BZ/14.png'),(34,'Beomy','https://i.ibb.co/BwDfx0f/34.png'),(36,'Hello Inyong','https://i.ibb.co/ZHXvxwW/35.png'),(35,'지단로보트','https://i.ibb.co/ZHXvxwW/35.png'),(22,'당근마켓','https://i.ibb.co/ZN4wrsz/22.png'),(37,'에디의 기술블로그','https://i.ibb.co/R9npW2G/brunch.png'),(38,'기억보단 기록을','https://i.ibb.co/ZHXvxwW/35.png'),(39,'hudi.blog','https://i.ibb.co/D8XgBqG/39.png'),(40,'Outsider\'s Dev Stroy','https://i.ibb.co/JykDJ2v/40.png'),(41,'Sangkon Han','https://i.ibb.co/QKd9C1t/41.png');
/*!40000 ALTER TABLE `techblog` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-18 11:25:20
